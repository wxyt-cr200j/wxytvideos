# (A)NTE js lcd开发教程

<style>
/* This element defines the size the iframe will take.
   In this example we want to have a ratio of 25:14 */
.aspect-ratio {
  position: relative;
  width: 100%;
  height: 0;
  padding-bottom: 56.25%; /* The height of the item will now be 56.25% of the width. */
}
/* Adjust the iframe so it's rendered in the outer-width and outer-height of it's parent */
.aspect-ratio iframe {
  position: absolute;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
}
</style>

<div class="aspect-ratio">
<iframe src="//player.bilibili.com/player.html?aid=818254400&bvid=BV1kG4y1G7yx&cid=910363279&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>
</div>

![Feature Grid](img/featgrid.jpg)

  
  
  
## js制作方法

请在左侧侧边栏内查看。
  
  
  
## 下载模板

请参见 [下载](download.md)。


